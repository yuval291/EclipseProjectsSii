package com.example.yuval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YuvalApplication {

	public static void main(String[] args) {
		SpringApplication.run(YuvalApplication.class, args);
	}

}
