package com.example.yuval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuvalApplicationTests {

	@Test
	void contextLoads() {
	}

}
